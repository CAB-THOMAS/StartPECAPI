/**
 * @prettier
 */
import React from "react"

import { createOnlyOAS32ComponentWrapper } from "../fn"
import { makeGetSchemaKeywords } from "../json-schema-2020-12-extensions/fn"

const ModelsWrapper = createOnlyOAS32ComponentWrapper(({ getSystem }) => {
  const { getComponent, fn, getConfigs } = getSystem()
  const configs = getConfigs()

  const pathname = window?.location?.pathname ?? "/"

  if (
    ModelsWrapper.ModelsWithJSONSchemaContext &&
    ModelsWrapper.pathname === pathname
  ) {
    return <ModelsWrapper.ModelsWithJSONSchemaContext />
  }

  const Models = getComponent("OAS31Models", true)
  const withJSONSchemaSystemContext = getComponent(
    "withJSONSchema202012SystemContext"
  )

  // we cache the HOC as recreating it with every re-render is quite expensive
  ModelsWrapper.ModelsWithJSONSchemaContext = withJSONSchemaSystemContext(
    Models,
    {
      config: {
        default$schema: "https://spec.openapis.org/oas/3.2/schema/2025-09-17",
        defaultExpandedLevels: configs.defaultModelsExpandDepth - 1,
        includeReadOnly: true,
        includeWriteOnly: true,
      },
      fn: {
        getProperties: fn.jsonSchema202012.getProperties,
        isExpandable: fn.jsonSchema202012.isExpandable,
        getSchemaKeywords: makeGetSchemaKeywords(
          fn.jsonSchema202012.getSchemaKeywords
        ),
      },
    }
  )
  ModelsWrapper.pathname = pathname

  return <ModelsWrapper.ModelsWithJSONSchemaContext />
})

ModelsWrapper.ModelsWithJSONSchemaContext = null
ModelsWrapper.pathname = null

export default ModelsWrapper
